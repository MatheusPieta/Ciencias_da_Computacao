def busca_reversa():
    

def main():
    

if __name__ == "__main__":
    main()