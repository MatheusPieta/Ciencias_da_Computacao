valor1 = int(input("Digite um primeiro valor: "))
valor2 = int(input("Digite um segundo valor: "))

if(valor1>valor2):
    print('Voalor 1 maior que valor 2: ', valor1)
elif(valor2>valor1):
    print('Valor 2 maior que valor 1: ', valor2)
else:
    print('Valor 1 é igual o Valor 2')
