valor = int(input("Digite valor: "))
cont= valor%2
if(cont==0):
    print("valor par")
else:
    print("valor impar")