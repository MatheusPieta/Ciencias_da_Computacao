valor1 = int(input("Digite um primeiro valor: "))
valor2 = int(input("Digite um segundo valor: "))
if(valor1>valor2):
    print('Valor 1 é maior que o valor 2')