n1 = int(input("Digite um valor: "))
if(n1<10):
    print("F1")
elif(n1>10<=100):
    print("F2")
elif(n1>100):
    print("F3")
