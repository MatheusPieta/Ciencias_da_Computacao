a = int(input("insira um valor: "))
b = int(input("insira outro valor: "))
c = int(input("insira outro valor: "))

if(a+b>=c):
    print ("seu valor é maior ou igual a C")
else:
    print ("seu valor é menor que c")