numero = 907
soma = 0
while numero > 85:
    numero = numero - 1
    if numero%2==0:
        soma = soma + numero
        print("Pares= ",numero)
print ("Soma dos numeros pares de 85 a 907 é = ", soma)
print ("fim")
