divisor = 1
while divisor <= 10:
    numero = 1
    while numero <= 10:
        na = numero*divisor
        print (numero , "X", divisor, "=", na)
        numero += 1
    print(20*"-")
    divisor += 1