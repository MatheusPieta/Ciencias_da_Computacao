base = int(input("Digite a base: "))
expoente = int(input("Digite o expoente: "))
i  = 0
x_i = 1

while i < expoente:
    i = i + 1 
    x_i = x_i * base 

print("O valor de", base, "elevado a", expoente, "é", x_i) 