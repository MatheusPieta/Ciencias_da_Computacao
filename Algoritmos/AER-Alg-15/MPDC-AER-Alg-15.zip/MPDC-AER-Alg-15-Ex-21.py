num = int(input("Digite um numero: "))
soma = 0
x = 1
while x <= num:
    soma = soma + (1/x)
    x += 1
print("O resultado de A é: ", soma)