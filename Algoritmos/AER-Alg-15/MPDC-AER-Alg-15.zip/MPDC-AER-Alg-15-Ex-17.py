numero = 1
soma = 0
while numero <= 100:
    numero = numero + 1
    soma = soma + numero
print ("Soma do numero 1 ao 100 = ", soma)
