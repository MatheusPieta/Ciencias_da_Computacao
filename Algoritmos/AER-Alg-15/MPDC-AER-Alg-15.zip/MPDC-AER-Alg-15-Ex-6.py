numero1 = 25
numero2 = 40
soma = 0
while numero2>25:
    numero2= numero2-1
    if numero2%2==0:
            print(numero2)
            soma = soma + numero2
print(soma)
print ("Fim do programa...")