numero = 0
soma = 0
while numero <= 10:
    print("numero :", numero,"soma= ", soma)
    numero = numero + 1
    soma = soma + numero
print ("fim")