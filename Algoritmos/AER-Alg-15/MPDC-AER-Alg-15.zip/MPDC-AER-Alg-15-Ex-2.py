numero = 10
while numero > 0:
    print("numero: ", numero)
    numero = numero - 1
print ("fim")
