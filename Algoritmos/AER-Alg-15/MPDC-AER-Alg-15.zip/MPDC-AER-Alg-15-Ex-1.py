numero = 1
while numero < 11:
    print("numero :", numero)
    numero = numero + 1
print ("fim")
