numero = 1000
while numero > 1:
    numero = numero - 1
    if numero%7==0:
        print("Pares= ",numero)
print ("fim")
