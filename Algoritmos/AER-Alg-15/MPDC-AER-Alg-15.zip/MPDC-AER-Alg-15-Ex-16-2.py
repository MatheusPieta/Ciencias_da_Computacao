numero = 105
while numero > 0:
    numero = numero - 1
    if numero%5==0:
        print("Numeros multiplos de 5= ",numero)
print ("fim")