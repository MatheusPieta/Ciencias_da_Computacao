numero = 11
while numero >= 0:
    numero = numero - 1
    if numero%2==0:
        print("Pares= ",numero)
print ("fim")
