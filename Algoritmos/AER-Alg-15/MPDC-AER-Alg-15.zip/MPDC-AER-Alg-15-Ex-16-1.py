numero = 105
while numero > 0:
    numero = numero - 5
    print("Numeros multiplos de 5= ",numero)