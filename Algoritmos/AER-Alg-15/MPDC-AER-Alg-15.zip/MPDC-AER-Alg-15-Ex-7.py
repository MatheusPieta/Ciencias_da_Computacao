numero1 = int(input("Digite o inicio do intervalo: "))
numero2 = int(input("Digite o Fim do intervalo: "))
while numero2>=numero1:
    print("numeros do intervalo: ", numero2)
    numero2 = numero2 - 1
print ("fim")
