n=int(input("Digite um numero:"))
soma=0
while n>0:
    soma=soma+1
    n=n//10
print("A quantidade de digitos é:", soma)