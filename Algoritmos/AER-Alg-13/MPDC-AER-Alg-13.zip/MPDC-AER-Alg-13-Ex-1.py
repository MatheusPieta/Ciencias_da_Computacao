nota1 = float(input("Digite sua nota em Português: "))
nota2 = float(input("Digite sua nota em Matemática: "))

media = (nota1+nota2)/2
print("Sua Média é igual a: ",(media))