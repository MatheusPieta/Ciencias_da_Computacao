soma = 0
for i in range(25,40):
    if i%2 ==0:
        soma = soma + i
print(20*"-")
print("Soma dos numeros pares entre 25 a 40: ", soma)
print(20*"-")