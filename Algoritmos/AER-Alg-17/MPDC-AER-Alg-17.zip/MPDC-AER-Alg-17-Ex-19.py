for i in range(1,1001):
    if i%7==0:
        print("Multiplos de 7= ",i)
print ("fim")
