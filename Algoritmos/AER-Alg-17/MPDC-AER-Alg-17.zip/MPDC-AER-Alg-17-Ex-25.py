n = input("Digite um numero")
d = 0
for c in n:
    d=d+1
print("Total de digitos é: ")
    