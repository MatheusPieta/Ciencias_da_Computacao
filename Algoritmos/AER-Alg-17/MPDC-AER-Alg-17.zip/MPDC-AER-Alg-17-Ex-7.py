numero1 = int(input("Digite o inicio do intervalo: "))
numero2 = int(input("Digite o Fim do intervalo: "))
for i in range(numero1,numero2+1):
    print("numeros do intervalo: ", i)
print ("fim")
