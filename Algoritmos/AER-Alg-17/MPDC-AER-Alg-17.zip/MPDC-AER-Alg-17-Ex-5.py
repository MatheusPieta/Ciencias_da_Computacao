soma = 0
for i in range(1,11):
    print("Numero=", i)
    soma = soma + i
    print ("Soma= ", soma)
