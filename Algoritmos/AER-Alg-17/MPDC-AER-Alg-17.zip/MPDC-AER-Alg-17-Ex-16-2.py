for i in range(100,-1,-1):
    if i%5==0:
        print(i)