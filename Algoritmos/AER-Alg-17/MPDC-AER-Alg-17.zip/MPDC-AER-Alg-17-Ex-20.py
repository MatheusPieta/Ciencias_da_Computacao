soma = 0
for i in range(85,908):
    if i%2==0:
        soma = soma + i
        print("Pares= ",i)
print ("Soma dos numeros pares de 85 a 907 é = ", soma)
print ("fim")
