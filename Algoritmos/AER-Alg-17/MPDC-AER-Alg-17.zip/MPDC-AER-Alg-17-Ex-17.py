numero1 = 1
numero2 = 100
soma = 0
for i in range(numero1,numero2+1):
    soma = soma + i
print(20*"-")
print("Soma dos numeros entre", numero1, "a", numero2, "é:", soma)
print(20*"-")