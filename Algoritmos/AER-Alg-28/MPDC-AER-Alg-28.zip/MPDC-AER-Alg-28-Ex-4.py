f = open(r"C:\Users\Matheus\Google Drive\Faculdade - Disciplinas\Algoritmos\AER-Alg-28\cabeçalho.txt") 
for line in f: 
    print("ARQ 1:", line.rstrip()) 
f.close()

f = open(r"C:\Users\Matheus\Google Drive\Faculdade - Disciplinas\Algoritmos\AER-Alg-28\cabeçalho2.txt") 
for line in f: 
    print("ARQ 2:", line.rstrip()) 
f.close()
