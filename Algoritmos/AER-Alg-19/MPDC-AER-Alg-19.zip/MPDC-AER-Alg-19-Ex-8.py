def calcula_percent(a, b):
    calcula = a/b
    print(calcula)


def main():
    a = float(input("Digite um numero: "))
    b = int(input("Digite um numero: "))
    calcula_percent(a, b)

if __name__ == "__main__":
    main()