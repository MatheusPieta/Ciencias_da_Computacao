a = int(input('Digite o primeiro número'))
b = int(input('Digite o primeiro número'))

x = a


a = b
b = x

print('Valor de A; ', a , '\nValor de B: ', b)